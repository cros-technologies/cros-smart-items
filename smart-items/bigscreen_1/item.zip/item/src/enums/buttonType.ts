export enum ButtonType {
    VisitWebSite,
    Transport
}