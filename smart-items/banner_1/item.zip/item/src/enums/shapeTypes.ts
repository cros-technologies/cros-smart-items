export enum ShapeType {
    Plain,
    Box,
    Gltf
}