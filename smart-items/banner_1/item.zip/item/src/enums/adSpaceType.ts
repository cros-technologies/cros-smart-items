export enum AdSpaceType {
    AdContent,
    QR
}