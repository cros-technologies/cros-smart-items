export class ObjectMap {
    key: string | undefined;
    value: object | undefined;
} 